<?php

namespace Kai;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;

class Main extends PluginBase implements Listener{

public $prefix = "§4Title§7 | §7";

public function onEnable(){

}

public function onDisable(){

}

public function onJoin(event $event){

$player = $event->getPlayer()

@mkdir('home/Datenbank/Title/player->getName() "yml", Config::YML')
$player->addTitle("§6Registriert")
$player->addsubTitle("§6Registriert")

$player->sendMessage("$this->prefix . Du kannst das Plugin in der Main.php ändern! Das Plugin ist von Kai!")

$player->setJoinMessage("§7[ §a+ §7] §a$player->getName()")

}

public function onQuit(event $event){

$player = $event->getPlayer()

$player->setQuitMessage("§7[ §c- §7] §c$player->getName()")

}
}